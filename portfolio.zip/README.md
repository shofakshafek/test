# Personal Portfolio & Digital CV

Website portofolio dan CV digital multi-halaman (20 rute) dengan konten placeholder generik. Seluruh konten dikelola dari satu file: `src/data/data.js`.

> Status: kode ditulis tetapi **belum di-install, di-build, atau diuji** (lingkungan pembuatan tanpa akses jaringan). Jalankan `npm install && npm run build` dan periksa hasilnya sebelum rilis.

## Tech stack
React 18, Vite 5, React Router 6, Lucide React, CSS modular (token + dark/light theme). Tanpa backend wajib.

## Struktur folder
- `public/` favicon, robots.txt, sitemap.xml, manifest, `_redirects` (Netlify), `images/`
- `src/data/data.js` seluruh konten
- `src/assets/styles/` tokens, global, animations, responsive, print
- `src/components/` `common/ui.jsx` (Container, Section, Badge, Button, EmptyState, Toast, SEO, ErrorBoundary, BackToTop, ScrollToTop, SocialLinks), `layout/Layout.jsx` (Navbar, MobileMenu, ThemeToggle, Footer), `projects/ProjectCard.jsx`, `forms/ContactForm.jsx`
- `src/pages/` Home, About, CV, Projects, ProjectDetail, Lists (Skills, Education, Experience, Organizations, Services, Certificates, Achievements), Forms (Contact, Collaboration, Donations), Blog (Blog, ArticleDetail), Misc (FAQ, Privacy, NotFound)
- `src/routes/AppRoutes.jsx` seluruh routing

## Menjalankan
```bash
npm install
npm run dev       # development
npm run build     # production -> dist/
npm run preview   # cek hasil build
```

## Mengubah konten (semua di `src/data/data.js`)
- **Identitas/foto/CV**: edit `identity`. Taruh `profile.jpg` dan `cv.pdf` di `public/`, lalu isi `photo: '/images/profile.jpg'` dan `cvPdf: '/cv.pdf'`. Tombol unduh CV aktif hanya jika `cvPdf` terisi.
- **Tambah project**: tambah objek ke `projects` (slug unik → URL `/projects/<slug>`).
- **Tambah pendidikan**: tambah objek ke `education`. Pengalaman, organisasi, sertifikat, prestasi, artikel: isi array masing-masing.
- **Sosial media**: isi `url` di `socialLinks` (yang kosong tidak ditampilkan).
- **Donasi**: set `donations.enabled = true` dan isi `methods` (nama, url, rekening, `qrImage`). Jangan memasukkan tautan/QR palsu.
- **Form**: daftar layanan form (Formspree, Web3Forms, API sendiri), lalu isi `VITE_FORM_ENDPOINT` di `.env` (salin dari `.env.example`). Tanpa itu, form menampilkan status "belum terhubung" dan tombol kirim nonaktif. Jangan simpan secret privat di frontend.
- **SEO**: ubah `siteConfig.url`, `seo`, serta `public/sitemap.xml` dan `public/robots.txt` ke domain asli.

## Deployment
- **Vercel**: import repo, framework Vite, build `npm run build`, output `dist`. `vercel.json` sudah menangani SPA fallback.
- **Netlify**: build `npm run build`, publish `dist`. `public/_redirects` sudah menangani SPA fallback.

## Troubleshooting
- Halaman 404 saat refresh di hosting: pastikan `vercel.json` / `_redirects` ikut ter-deploy.
- Form tidak mengirim: periksa `VITE_FORM_ENDPOINT` dan rebuild setelah mengubah `.env`.
- Tema tidak tersimpan: browser memblokir localStorage; tema default dari `siteConfig.defaultTheme`.
