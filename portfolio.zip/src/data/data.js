// SATU-SATUNYA sumber konten website. Ganti placeholder di sini; kosongkan array bila belum ada data.
export const siteConfig = {
  url: 'https://example.com', // domain canonical
  defaultTheme: 'dark',
  formEndpoint: import.meta.env.VITE_FORM_ENDPOINT || '',
};

export const identity = {
  fullName: 'Nama Lengkap',
  nickname: 'Nama',
  brand: 'YOUR BRAND',
  role: 'Web Developer',
  headline: 'Building Digital Experiences',
  location: 'Kota, Provinsi, Indonesia',
  email: 'email@example.com',
  photo: '', // contoh: '/images/profile.jpg'
  cvPdf: '', // contoh: '/cv.pdf' (taruh file di public/)
};

export const profile = {
  summary: 'Ringkasan singkat tentang Anda. Ganti teks ini di src/data/data.js.',
};

export const availability = { status: 'available', text: 'Status ketersediaan: ganti di data.js' };

export const about = {
  bio: 'Biografi belum diisi.',
  interests: [],
  journey: '',
  principles: [],
  goals: '',
  values: [],
};

export const education = [
  { school: 'Nama Sekolah', level: '', major: 'Nama Jurusan', start: '20XX', end: '20XX', status: '', activities: [], achievements: [] },
];

// type: 'formal' | 'freelance' | 'internship' | 'organisasi' | 'volunteer' | 'open-source' | 'personal'
export const experiences = [];
export const organizations = [];

// Kategori: frontend, backend, languages, database, devops, design, soft. Tanpa persentase.
export const skills = { frontend: [], backend: [], languages: [], database: [], devops: [], design: [], soft: [] };
export const tools = [];

export const projects = [
  {
    slug: 'nama-project',
    title: 'Nama Project',
    description: 'Deskripsi Project',
    category: 'Web',
    tech: ['Teknologi yang Digunakan'],
    year: '20XX',
    status: 'Draft',
    featured: true,
    thumbnail: '',
    gallery: [],
    demo: '',
    repo: '',
    details: 'Detail project belum diisi.',
  },
];

export const services = [
  { title: 'Nama Layanan', description: 'Deskripsi layanan.', deliverables: [], tech: [], estimate: '', price: '' },
];
export const certificates = []; // { title, issuer, year, url }
export const achievements = []; // { title, year, description }
export const testimonials = []; // { name, role, text }
export const timeline = []; // { year, title, text }
export const languages = []; // { name, level }

export const socialLinks = [
  { name: 'GitHub', url: '', icon: 'Github' },
  { name: 'Instagram', url: '', icon: 'Instagram' },
  { name: 'Telegram', url: '', icon: 'Send' },
  { name: 'LinkedIn', url: '', icon: 'Linkedin' },
];

export const donations = {
  enabled: false,
  purpose: '',
  usage: '',
  target: null, // { amount: 0, label: '' } (opsional)
  methods: [], // { name, description, url, account, qrImage }
  faq: [],
};

export const collaborations = { types: ['Freelance', 'Proyek bersama', 'Mentoring', 'Lainnya'] };
export const contact = { categories: ['Pertanyaan umum', 'Tawaran kerja', 'Kolaborasi', 'Lainnya'] };

// article: { slug, title, excerpt, content: [paragraf], date, category, tags: [] }
export const articles = [];

export const faq = [
  { q: 'Apakah website ini memakai data asli?', a: 'Belum. Semua konten adalah placeholder dan dikelola dari src/data/data.js.' },
];

export const navigation = {
  main: [
    { label: 'Home', path: '/' }, { label: 'About', path: '/about' }, { label: 'CV', path: '/cv' },
    { label: 'Projects', path: '/projects' }, { label: 'Skills', path: '/skills' },
    { label: 'Services', path: '/services' }, { label: 'Blog', path: '/blog' }, { label: 'Contact', path: '/contact' },
  ],
  more: [
    { label: 'Education', path: '/education' }, { label: 'Experience', path: '/experience' },
    { label: 'Organizations', path: '/organizations' }, { label: 'Certificates', path: '/certificates' },
    { label: 'Achievements', path: '/achievements' }, { label: 'Donations', path: '/donations' },
    { label: 'Collaboration', path: '/collaboration' }, { label: 'FAQ', path: '/faq' }, { label: 'Privacy', path: '/privacy' },
  ],
};

export const seo = {
  defaultTitle: 'YOUR BRAND — Portfolio & Digital CV',
  titleTemplate: '%s | YOUR BRAND',
  description: 'Portfolio dan CV digital. Ganti deskripsi ini di data.js.',
};

export const footer = { text: '© YOUR BRAND. Seluruh hak dilindungi.' };

export const privacy = {
  updated: '20XX',
  sections: [
    { title: 'Data yang dikumpulkan', text: 'Website ini hanya menyimpan preferensi tema di browser Anda. Data formulir dikirim ke layanan yang dikonfigurasi pemilik website.' },
    { title: 'Kontak', text: 'Pertanyaan privasi dapat dikirim melalui halaman Contact.' },
  ],
};
