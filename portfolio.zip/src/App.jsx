import { useLocation } from 'react-router-dom';
import { ErrorBoundary, ToastProvider, ScrollToTop, BackToTop } from './components/common/ui.jsx';
import { Navbar, Footer } from './components/layout/Layout.jsx';
import AppRoutes from './routes/AppRoutes.jsx';

export default function App() {
  const { pathname } = useLocation();
  return (
    <ErrorBoundary>
      <ToastProvider>
        <ScrollToTop />
        <a className="skip" href="#main">Lewati ke konten</a>
        <Navbar />
        <main id="main" key={pathname} className="page"><AppRoutes /></main>
        <Footer />
        <BackToTop />
      </ToastProvider>
    </ErrorBoundary>
  );
}
