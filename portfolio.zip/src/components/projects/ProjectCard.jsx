import { Link } from 'react-router-dom';
import { Badge, EmptyState } from '../common/ui.jsx';

export function ProjectCard({ p }) {
  return (
    <article className="card project">
      {p.thumbnail ? <img src={p.thumbnail} alt={`Thumbnail ${p.title}`} loading="lazy" /> : <div className="thumb" aria-hidden="true" />}
      <div className="card-body">
        <div className="row between wrap"><Badge>{p.category}</Badge><span className="muted">{p.year} · {p.status}</span></div>
        <h3 style={{ marginTop: '.6rem' }}><Link to={`/projects/${p.slug}`}>{p.title}</Link></h3>
        <p className="muted">{p.description}</p>
        <div className="row wrap">{p.tech.map((t) => <Badge key={t}>{t}</Badge>)}</div>
      </div>
    </article>
  );
}

export const ProjectGrid = ({ items }) => items.length
  ? <div className="grid">{items.map((p) => <ProjectCard key={p.slug} p={p} />)}</div>
  : <EmptyState title="Project tidak ditemukan" text="Ubah kata kunci atau filter pencarian." />;
