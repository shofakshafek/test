import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, Moon, Sun, X, Copy } from 'lucide-react';
import { footer, identity, navigation, siteConfig } from '../../data/data.js';
import { Container, SocialLinks, useToast } from '../common/ui.jsx';

export function ThemeToggle() {
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem('theme') || siteConfig.defaultTheme; } catch { return siteConfig.defaultTheme; }
  });
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('theme', theme); } catch { /* storage tidak tersedia */ }
  }, [theme]);
  const dark = theme === 'dark';
  return (
    <button className="icon-btn" aria-label={dark ? 'Ganti ke tema terang' : 'Ganti ke tema gelap'} onClick={() => setTheme(dark ? 'light' : 'dark')}>
      {dark ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}

export function MobileMenu() {
  return (
    <nav className="mobile" aria-label="Menu mobile">
      {[...navigation.main, ...navigation.more].map((n) => <NavLink key={n.path} to={n.path} end={n.path === '/'}>{n.label}</NavLink>)}
    </nav>
  );
}

export function Navbar() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => setOpen(false), [pathname]);
  return (
    <header className="nav">
      <Container className="nav-in">
        <Link to="/" className="brand">{identity.brand}</Link>
        <nav className="links" aria-label="Navigasi utama">
          {navigation.main.map((n) => <NavLink key={n.path} to={n.path} end={n.path === '/'}>{n.label}</NavLink>)}
        </nav>
        <div className="nav-actions">
          <ThemeToggle />
          <button className="icon-btn menu-btn" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X size={18} /> : <Menu size={18} />}</button>
        </div>
      </Container>
      {open && <MobileMenu />}
    </header>
  );
}

export function Footer() {
  const toast = useToast();
  const copy = async () => {
    try { await navigator.clipboard.writeText(identity.email); toast('Email disalin.'); } catch { toast('Gagal menyalin. Salin manual: ' + identity.email); }
  };
  return (
    <footer className="footer">
      <Container>
        <nav aria-label="Navigasi footer">{navigation.more.map((n) => <Link key={n.path} to={n.path}>{n.label}</Link>)}</nav>
        <div className="row wrap between" style={{ marginTop: '1rem' }}>
          <span className="muted">{footer.text}</span>
          <button className="btn ghost" onClick={copy}><Copy size={16} /> Salin email</button>
        </div>
        <SocialLinks />
      </Container>
    </footer>
  );
}
