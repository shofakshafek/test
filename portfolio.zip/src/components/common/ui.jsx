import { Component, createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ArrowUp, Github, Instagram, Linkedin, Send, Globe } from 'lucide-react';
import { identity, seo, siteConfig, socialLinks } from '../../data/data.js';

export const Container = ({ children, className = '' }) => <div className={`container ${className}`}>{children}</div>;

export function Section({ children, className = '', id }) {
  const ref = useRef(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || !('IntersectionObserver' in window)) { setSeen(true); return; }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setSeen(true); io.disconnect(); } }, { threshold: 0.08 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <section id={id} ref={ref} className={`section reveal ${seen ? 'in' : ''} ${className}`}><Container>{children}</Container></section>;
}

export const SectionHeading = ({ title, subtitle }) => (
  <div className="heading"><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>
);
export const Badge = ({ children }) => <span className="badge">{children}</span>;

export function Button({ to, href, variant = 'primary', children, ...rest }) {
  const cls = `btn ${variant}`;
  if (to) return <Link className={cls} to={to} {...rest}>{children}</Link>;
  if (href) return <a className={cls} href={href} target="_blank" rel="noopener noreferrer" {...rest}>{children}</a>;
  return <button type="button" className={cls} {...rest}>{children}</button>;
}

export const EmptyState = ({ title = 'Belum ada data', text = 'Tambahkan konten di src/data/data.js agar tampil di sini.' }) => (
  <div className="empty"><h3>{title}</h3><p>{text}</p></div>
);

export const Item = ({ title, sub, meta, text, list = [], tags = [] }) => (
  <article className="card pad">
    <div className="row between wrap"><h3>{title}</h3>{meta && <span className="muted">{meta}</span>}</div>
    {sub && <p className="muted">{sub}</p>}
    {text && <p>{text}</p>}
    {list.length > 0 && <ul>{list.map((x) => <li key={x}>{x}</li>)}</ul>}
    {tags.length > 0 && <div className="row wrap">{tags.map((t) => <Badge key={t}>{t}</Badge>)}</div>}
  </article>
);

const ICONS = { Github, Instagram, Linkedin, Send };
export function SocialLinks() {
  const links = socialLinks.filter((s) => s.url);
  if (!links.length) return null;
  return (
    <div className="social">
      {links.map((s) => { const I = ICONS[s.icon] || Globe; return (
        <a key={s.name} className="icon-btn" href={s.url} target="_blank" rel="noopener noreferrer" aria-label={s.name}><I size={18} /></a>
      ); })}
    </div>
  );
}

const ToastCtx = createContext(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }) {
  const [msg, setMsg] = useState('');
  const timer = useRef();
  const show = useCallback((m) => { setMsg(m); clearTimeout(timer.current); timer.current = setTimeout(() => setMsg(''), 3000); }, []);
  return <ToastCtx.Provider value={show}>{children}{msg && <div className="toast" role="status">{msg}</div>}</ToastCtx.Provider>;
}

export function SEO({ title, description }) {
  const { pathname } = useLocation();
  useEffect(() => {
    const full = title ? seo.titleTemplate.replace('%s', title) : seo.defaultTitle;
    const desc = description || seo.description;
    document.title = full;
    const put = (tag, attr, key, prop, val) => {
      let el = document.head.querySelector(`${tag}[${attr}="${key}"]`);
      if (!el) { el = document.createElement(tag); el.setAttribute(attr, key); document.head.appendChild(el); }
      el.setAttribute(prop, val);
    };
    put('meta', 'name', 'description', 'content', desc);
    put('meta', 'property', 'og:title', 'content', full);
    put('meta', 'property', 'og:description', 'content', desc);
    put('meta', 'property', 'og:type', 'content', 'website');
    put('link', 'rel', 'canonical', 'href', siteConfig.url + pathname);
    let ld = document.getElementById('ld-person');
    if (!ld) { ld = document.createElement('script'); ld.id = 'ld-person'; ld.type = 'application/ld+json'; document.head.appendChild(ld); }
    ld.textContent = JSON.stringify({ '@context': 'https://schema.org', '@type': 'Person', name: identity.fullName, jobTitle: identity.role, url: siteConfig.url });
  }, [title, description, pathname]);
  return null;
}

export class ErrorBoundary extends Component {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() {
    if (!this.state.failed) return this.props.children;
    return <Container><EmptyState title="Terjadi kesalahan" text="Muat ulang halaman. Jika masalah berlanjut, periksa console browser." /></Container>;
  }
}

export function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

export function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const on = () => setShow(window.scrollY > 500);
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);
  if (!show) return null;
  return <button className="icon-btn totop" aria-label="Kembali ke atas" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}><ArrowUp size={18} /></button>;
}
