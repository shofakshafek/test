import { useState } from 'react';
import { siteConfig } from '../../data/data.js';
import { useToast } from '../common/ui.jsx';

export default function ContactForm({ categories, kind = 'contact' }) {
  const toast = useToast();
  const connected = Boolean(siteConfig.formEndpoint);
  const [v, setV] = useState({ name: '', email: '', category: categories[0] || '', message: '' });
  const [err, setErr] = useState({});
  const [status, setStatus] = useState('idle');
  const set = (k) => (e) => setV({ ...v, [k]: e.target.value });

  const validate = () => {
    const e = {};
    if (v.name.trim().length < 2) e.name = 'Nama minimal 2 karakter.';
    if (!/^\S+@\S+\.\S+$/.test(v.email)) e.email = 'Format email tidak valid.';
    if (v.message.trim().length < 10) e.message = 'Pesan minimal 10 karakter.';
    return e;
  };
  const submit = async (ev) => {
    ev.preventDefault();
    const e = validate();
    setErr(e);
    if (Object.keys(e).length || !connected) return;
    setStatus('loading');
    try {
      const r = await fetch(siteConfig.formEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ kind, ...v }) });
      if (!r.ok) throw new Error(String(r.status));
      setStatus('success'); toast('Pesan terkirim.');
      setV({ ...v, name: '', email: '', message: '' });
    } catch { setStatus('error'); toast('Pesan gagal dikirim. Coba lagi.'); }
  };

  return (
    <form className="form" onSubmit={submit} noValidate>
      {!connected && <p className="notice">Formulir belum terhubung ke layanan pengiriman. Isi VITE_FORM_ENDPOINT di file .env agar bisa mengirim pesan.</p>}
      <label>Nama<input value={v.name} onChange={set('name')} autoComplete="name" />{err.name && <span className="err">{err.name}</span>}</label>
      <label>Email<input type="email" value={v.email} onChange={set('email')} autoComplete="email" />{err.email && <span className="err">{err.email}</span>}</label>
      <label>Kategori<select value={v.category} onChange={set('category')}>{categories.map((c) => <option key={c}>{c}</option>)}</select></label>
      <label>Pesan<textarea rows={5} value={v.message} onChange={set('message')} />{err.message && <span className="err">{err.message}</span>}</label>
      <button className="btn primary" disabled={!connected || status === 'loading'}>{status === 'loading' ? 'Mengirim…' : 'Kirim pesan'}</button>
      {status === 'success' && <p className="notice" role="status">Pesan terkirim. Terima kasih.</p>}
      {status === 'error' && <p className="err" role="alert">Pesan gagal dikirim. Periksa koneksi atau endpoint form.</p>}
    </form>
  );
}
