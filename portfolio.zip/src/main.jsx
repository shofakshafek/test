import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import './assets/styles/tokens.css';
import './assets/styles/global.css';
import './assets/styles/animations.css';
import './assets/styles/responsive.css';
import './assets/styles/print.css';

createRoot(document.getElementById('root')).render(
  <StrictMode><BrowserRouter><App /></BrowserRouter></StrictMode>
);
