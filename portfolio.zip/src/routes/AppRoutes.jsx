import { Routes, Route } from 'react-router-dom';
import Home from '../pages/Home.jsx';
import About from '../pages/About.jsx';
import CV from '../pages/CV.jsx';
import Projects from '../pages/Projects.jsx';
import ProjectDetail from '../pages/ProjectDetail.jsx';
import { Skills, Education, Experience, Organizations, Services, Certificates, Achievements } from '../pages/Lists.jsx';
import { Donations, Collaboration, Contact } from '../pages/Forms.jsx';
import { Blog, ArticleDetail } from '../pages/Blog.jsx';
import { FAQ, Privacy, NotFound } from '../pages/Misc.jsx';

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/cv" element={<CV />} />
      <Route path="/projects" element={<Projects />} />
      <Route path="/projects/:slug" element={<ProjectDetail />} />
      <Route path="/skills" element={<Skills />} />
      <Route path="/education" element={<Education />} />
      <Route path="/experience" element={<Experience />} />
      <Route path="/organizations" element={<Organizations />} />
      <Route path="/services" element={<Services />} />
      <Route path="/certificates" element={<Certificates />} />
      <Route path="/achievements" element={<Achievements />} />
      <Route path="/donations" element={<Donations />} />
      <Route path="/collaboration" element={<Collaboration />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/blog" element={<Blog />} />
      <Route path="/blog/:slug" element={<ArticleDetail />} />
      <Route path="/faq" element={<FAQ />} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
