import { about, timeline } from '../data/data.js';
import { Badge, EmptyState, Item, SEO, Section, SectionHeading } from '../components/common/ui.jsx';

export default function About() {
  const lists = [['Minat teknologi', about.interests], ['Prinsip kerja', about.principles], ['Nilai pribadi', about.values]];
  return (
    <>
      <SEO title="About" description="Biografi, prinsip kerja, dan perjalanan profesional." />
      <Section>
        <SectionHeading title="Tentang saya" />
        <p>{about.bio}</p>
        {about.journey && <><h3>Perjalanan belajar</h3><p>{about.journey}</p></>}
        {about.goals && <><h3>Tujuan karier</h3><p>{about.goals}</p></>}
        {lists.map(([t, l]) => l.length > 0 && <div key={t}><h3>{t}</h3><div className="row wrap">{l.map((x) => <Badge key={x}>{x}</Badge>)}</div></div>)}
      </Section>
      <Section>
        <SectionHeading title="Timeline" />
        {timeline.length ? <div className="stack">{timeline.map((t) => <Item key={t.year + t.title} title={t.title} meta={t.year} text={t.text} />)}</div> : <EmptyState />}
      </Section>
    </>
  );
}
