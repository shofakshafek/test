import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { faq, privacy } from '../data/data.js';
import { Button, SEO, Section, SectionHeading } from '../components/common/ui.jsx';

export function FAQ() {
  const [open, setOpen] = useState(-1);
  return (
    <>
      <SEO title="FAQ" description="Pertanyaan yang sering diajukan." />
      <Section>
        <SectionHeading title="FAQ" />
        <div className="stack">
          {faq.map((f, i) => (
            <div key={f.q} className="card acc">
              <button aria-expanded={open === i} aria-controls={`faq-${i}`} onClick={() => setOpen(open === i ? -1 : i)}>{f.q}{open === i ? <Minus size={18} /> : <Plus size={18} />}</button>
              {open === i && <p id={`faq-${i}`}>{f.a}</p>}
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}

export function Privacy() {
  return (
    <>
      <SEO title="Privacy Policy" description="Kebijakan privasi." />
      <Section>
        <SectionHeading title="Privacy Policy" subtitle={`Terakhir diperbarui: ${privacy.updated}`} />
        {privacy.sections.map((s) => <div key={s.title}><h3>{s.title}</h3><p>{s.text}</p></div>)}
      </Section>
    </>
  );
}

export function NotFound() {
  return (
    <>
      <SEO title="404" description="Halaman tidak ditemukan." />
      <Section>
        <h1>404</h1>
        <p className="muted">Halaman yang Anda cari tidak ada atau sudah dipindahkan.</p>
        <Button to="/">Kembali ke Home</Button>
      </Section>
    </>
  );
}
