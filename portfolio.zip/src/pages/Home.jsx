import { identity, profile, availability, projects, skills, tools, education, services } from '../data/data.js';
import { Badge, Button, EmptyState, Item, SEO, Section, SectionHeading, SocialLinks } from '../components/common/ui.jsx';
import { ProjectGrid } from '../components/projects/ProjectCard.jsx';

export default function Home() {
  const featured = projects.filter((p) => p.featured);
  const allSkills = [...Object.values(skills).flat(), ...tools];
  return (
    <>
      <SEO />
      <Section className="hero">
        <div className="hero-grid">
          <div>
            <Badge>{availability.text}</Badge>
            <h1 style={{ marginTop: '1rem' }}>{identity.fullName}</h1>
            <p className="lead"><strong>{identity.role}</strong> · {identity.headline}</p>
            <p className="muted">{profile.summary}</p>
            <div className="row wrap">
              <Button to="/projects">Lihat project</Button>
              <Button to="/cv" variant="ghost">Buka CV</Button>
              <Button to="/contact" variant="ghost">Hubungi saya</Button>
            </div>
            <SocialLinks />
          </div>
          {identity.photo
            ? <img className="avatar" src={identity.photo} alt={`Foto ${identity.fullName}`} />
            : <div className="avatar ph" role="img" aria-label="Foto profil belum diatur">{identity.nickname[0]}</div>}
        </div>
      </Section>
      <Section><SectionHeading title="Project unggulan" />{featured.length ? <ProjectGrid items={featured} /> : <EmptyState />}</Section>
      <Section>
        <SectionHeading title="Skill" />
        {allSkills.length ? <div className="row wrap">{allSkills.map((s) => <Badge key={s}>{s}</Badge>)}</div> : <EmptyState />}
        <div style={{ marginTop: '1rem' }}><Button to="/skills" variant="ghost">Semua skill</Button></div>
      </Section>
      <Section>
        <SectionHeading title="Pendidikan" />
        <div className="stack">{education.map((e) => <Item key={e.school} title={e.school} sub={e.major} meta={`${e.start} – ${e.end}`} />)}</div>
      </Section>
      <Section>
        <SectionHeading title="Layanan" />
        <div className="grid">{services.map((s) => <Item key={s.title} title={s.title} text={s.description} />)}</div>
      </Section>
      <Section>
        <SectionHeading title="Mari bekerja sama" subtitle="Punya proyek atau ide? Ceritakan kebutuhan Anda." />
        <Button to="/collaboration">Ajukan kerja sama</Button>
      </Section>
    </>
  );
}
