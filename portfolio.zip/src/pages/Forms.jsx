import { Copy } from 'lucide-react';
import { availability, collaborations, contact, donations, identity, services } from '../data/data.js';
import { Badge, Button, EmptyState, Item, SEO, Section, SectionHeading, SocialLinks, useToast } from '../components/common/ui.jsx';
import ContactForm from '../components/forms/ContactForm.jsx';

export function Contact() {
  const toast = useToast();
  const copy = async () => { try { await navigator.clipboard.writeText(identity.email); toast('Email disalin.'); } catch { toast('Gagal menyalin email.'); } };
  return (
    <>
      <SEO title="Contact" description="Hubungi saya." />
      <Section>
        <SectionHeading title="Contact" subtitle={availability.text} />
        <div className="row wrap" style={{ marginBottom: '1rem' }}>
          <Button href={`mailto:${identity.email}`} variant="ghost" target="_self">{identity.email}</Button>
          <Button variant="ghost" onClick={copy}><Copy size={16} /> Salin email</Button>
        </div>
        <SocialLinks />
        <div style={{ marginTop: '1.5rem' }}><ContactForm categories={contact.categories} kind="contact" /></div>
      </Section>
    </>
  );
}

export function Collaboration() {
  return (
    <>
      <SEO title="Collaboration" description="Jenis kerja sama dan formulir pengajuan." />
      <Section>
        <SectionHeading title="Collaboration" subtitle={availability.text} />
        <div className="row wrap">{collaborations.types.map((t) => <Badge key={t}>{t}</Badge>)}</div>
        <h3 style={{ marginTop: '1.5rem' }}>Layanan</h3>
        <div className="grid">{services.map((s) => <Item key={s.title} title={s.title} text={s.description} />)}</div>
        <h3 style={{ marginTop: '1.5rem' }}>Ajukan kerja sama</h3>
        <ContactForm categories={collaborations.types} kind="collaboration" />
      </Section>
    </>
  );
}

export function Donations() {
  const on = donations.enabled && donations.methods.length > 0;
  return (
    <>
      <SEO title="Donations" description="Dukung karya saya." />
      <Section>
        <SectionHeading title="Donations" subtitle={donations.purpose} />
        {!on ? <EmptyState title="Donasi belum diaktifkan" text="Atur donations.enabled dan donations.methods di src/data/data.js." /> : (
          <div className="stack">
            {donations.usage && <p>{donations.usage}</p>}
            {donations.target && <p className="muted">Target: {donations.target.label}</p>}
            {donations.methods.map((m) => (
              <Item key={m.name} title={m.name} text={m.description} sub={m.account} />
            ))}
            {donations.methods.filter((m) => m.url).map((m) => <Button key={m.name} href={m.url}>Donasi via {m.name}</Button>)}
            {donations.methods.filter((m) => m.qrImage).map((m) => <img key={m.name} src={m.qrImage} alt={`QR ${m.name}`} width="220" loading="lazy" />)}
          </div>
        )}
        {donations.faq.length > 0 && <div className="stack" style={{ marginTop: '1.5rem' }}>{donations.faq.map((f) => <Item key={f.q} title={f.q} text={f.a} />)}</div>}
      </Section>
    </>
  );
}
