import { useMemo, useState } from 'react';
import { projects } from '../data/data.js';
import { SEO, Section, SectionHeading } from '../components/common/ui.jsx';
import { ProjectGrid } from '../components/projects/ProjectCard.jsx';

export default function Projects() {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [tech, setTech] = useState('');
  const [sort, setSort] = useState('new');
  const cats = [...new Set(projects.map((p) => p.category).filter(Boolean))];
  const techs = [...new Set(projects.flatMap((p) => p.tech))];
  const items = useMemo(() => projects
    .filter((p) => (!cat || p.category === cat) && (!tech || p.tech.includes(tech)) && `${p.title} ${p.description}`.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => sort === 'az' ? a.title.localeCompare(b.title) : String(b.year).localeCompare(String(a.year))), [q, cat, tech, sort]);
  return (
    <>
      <SEO title="Projects" description="Katalog project." />
      <Section>
        <SectionHeading title="Projects" />
        <div className="filters">
          <input type="search" placeholder="Cari project…" aria-label="Cari project" value={q} onChange={(e) => setQ(e.target.value)} />
          <select aria-label="Filter kategori" value={cat} onChange={(e) => setCat(e.target.value)}><option value="">Semua kategori</option>{cats.map((c) => <option key={c}>{c}</option>)}</select>
          <select aria-label="Filter teknologi" value={tech} onChange={(e) => setTech(e.target.value)}><option value="">Semua teknologi</option>{techs.map((t) => <option key={t}>{t}</option>)}</select>
          <select aria-label="Urutkan" value={sort} onChange={(e) => setSort(e.target.value)}><option value="new">Terbaru</option><option value="az">Nama A–Z</option></select>
        </div>
        <ProjectGrid items={items} />
      </Section>
    </>
  );
}
