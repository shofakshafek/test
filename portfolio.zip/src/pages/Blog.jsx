import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { articles } from '../data/data.js';
import { Badge, EmptyState, SEO, Section, SectionHeading } from '../components/common/ui.jsx';
import { NotFound } from './Misc.jsx';

const minutes = (a) => Math.max(1, Math.round((a.content || []).join(' ').split(/\s+/).length / 200));
const Card = ({ a }) => (
  <article className="card pad">
    <div className="row between wrap"><Badge>{a.category}</Badge><span className="muted">{a.date} · {minutes(a)} menit baca</span></div>
    <h3 style={{ marginTop: '.6rem' }}><Link to={`/blog/${a.slug}`}>{a.title}</Link></h3>
    <p className="muted">{a.excerpt}</p>
    <div className="row wrap">{(a.tags || []).map((t) => <Badge key={t}>#{t}</Badge>)}</div>
  </article>
);

export function Blog() {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const cats = [...new Set(articles.map((a) => a.category))];
  const items = useMemo(() => articles.filter((a) => (!cat || a.category === cat) && `${a.title} ${a.excerpt} ${(a.tags || []).join(' ')}`.toLowerCase().includes(q.toLowerCase())), [q, cat]);
  return (
    <>
      <SEO title="Blog" description="Artikel dan catatan." />
      <Section>
        <SectionHeading title="Blog" />
        {!articles.length ? <EmptyState title="Belum ada artikel" text="Artikel pertama akan tampil di sini setelah ditambahkan ke data.js." /> : (
          <>
            <div className="filters">
              <input type="search" placeholder="Cari artikel atau tag…" aria-label="Cari artikel" value={q} onChange={(e) => setQ(e.target.value)} />
              <select aria-label="Filter kategori" value={cat} onChange={(e) => setCat(e.target.value)}><option value="">Semua kategori</option>{cats.map((c) => <option key={c}>{c}</option>)}</select>
            </div>
            {items.length ? <div className="stack">{items.map((a) => <Card key={a.slug} a={a} />)}</div> : <EmptyState title="Artikel tidak ditemukan" text="Ubah kata kunci atau filter." />}
          </>
        )}
      </Section>
    </>
  );
}

export function ArticleDetail() {
  const { slug } = useParams();
  const a = articles.find((x) => x.slug === slug);
  if (!a) return <NotFound />;
  const related = articles.filter((x) => x.slug !== a.slug && (x.category === a.category || (x.tags || []).some((t) => (a.tags || []).includes(t)))).slice(0, 3);
  return (
    <>
      <SEO title={a.title} description={a.excerpt} />
      <Section>
        <Link to="/blog">← Semua artikel</Link>
        <h1 style={{ marginTop: '1rem' }}>{a.title}</h1>
        <p className="muted">{a.date} · {minutes(a)} menit baca · {a.category}</p>
        {(a.content || []).map((p, i) => <p key={i}>{p}</p>)}
        {related.length > 0 && <><h2>Artikel terkait</h2><div className="stack">{related.map((r) => <Card key={r.slug} a={r} />)}</div></>}
      </Section>
    </>
  );
}
