import { identity, profile, education, experiences, skills, tools, certificates, achievements, languages, projects } from '../data/data.js';
import { Button, Item, SEO, Section } from '../components/common/ui.jsx';

const Block = ({ title, items, render }) => items.length > 0 && <div className="cv-sec"><h2>{title}</h2><div className="stack">{items.map(render)}</div></div>;

export default function CV() {
  const skillGroups = Object.entries(skills).filter(([, v]) => v.length);
  return (
    <>
      <SEO title="Digital CV" description="Curriculum vitae digital yang dapat dicetak." />
      <Section>
        <div className="row between wrap no-print" style={{ marginBottom: '1.5rem' }}>
          <h1 style={{ fontSize: '2rem' }}>Digital CV</h1>
          <div className="row">
            <Button variant="ghost" onClick={() => window.print()}>Cetak CV</Button>
            <Button href={identity.cvPdf || undefined} download disabled={!identity.cvPdf} title={identity.cvPdf ? '' : 'File CV belum tersedia'}>Unduh PDF</Button>
          </div>
        </div>
        <header className="cv-sec"><h2>{identity.fullName}</h2><p>{identity.role} · {identity.location} · {identity.email}</p><p>{profile.summary}</p></header>
        <Block title="Pendidikan" items={education} render={(e) => <Item key={e.school} title={e.school} sub={e.major} meta={`${e.start} – ${e.end}`} />} />
        <Block title="Pengalaman" items={experiences} render={(x) => <Item key={x.title + x.org} title={x.title} sub={x.org} meta={x.period} text={x.description} />} />
        <Block title="Skill" items={skillGroups} render={([k, v]) => <Item key={k} title={k} tags={v} />} />
        {tools.length > 0 && <Item title="Tools" tags={tools} />}
        <Block title="Sertifikat" items={certificates} render={(c) => <Item key={c.title} title={c.title} sub={c.issuer} meta={c.year} />} />
        <Block title="Prestasi" items={achievements} render={(a) => <Item key={a.title} title={a.title} meta={a.year} text={a.description} />} />
        <Block title="Bahasa" items={languages} render={(l) => <Item key={l.name} title={l.name} meta={l.level} />} />
        <Block title="Project relevan" items={projects.filter((p) => p.featured)} render={(p) => <Item key={p.slug} title={p.title} meta={p.year} text={p.description} tags={p.tech} />} />
      </Section>
    </>
  );
}
