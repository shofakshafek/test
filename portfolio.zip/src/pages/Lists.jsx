import { skills, tools, education, experiences, organizations, services, certificates, achievements } from '../data/data.js';
import { Badge, Button, EmptyState, Item, SEO, Section, SectionHeading } from '../components/common/ui.jsx';

function ListPage({ title, sub, items, render, children }) {
  return (
    <>
      <SEO title={title} description={sub} />
      <Section>
        <SectionHeading title={title} subtitle={sub} />
        {items.length ? <div className="stack">{items.map(render)}</div> : <EmptyState />}
        {children}
      </Section>
    </>
  );
}

const LABELS = { frontend: 'Frontend', backend: 'Backend', languages: 'Bahasa pemrograman', database: 'Database', devops: 'DevOps', design: 'Desain', soft: 'Soft skills' };
export function Skills() {
  const groups = [...Object.entries(skills), ['tools', tools]].filter(([, v]) => v.length);
  return <ListPage title="Skills" sub="Dikelompokkan per kategori, tanpa persentase." items={groups}
    render={([k, v]) => <article key={k} className="card pad"><h3>{LABELS[k] || 'Tools'}</h3><div className="row wrap">{v.map((s) => <Badge key={s}>{s}</Badge>)}</div></article>} />;
}
export const Education = () => <ListPage title="Education" items={education}
  render={(e) => <Item key={e.school} title={e.school} sub={[e.level, e.major].filter(Boolean).join(' · ')} meta={`${e.start} – ${e.end}`} text={e.status} list={[...e.activities, ...e.achievements]} />} />;

export function Experience() {
  const pro = experiences.filter((x) => x.type !== 'personal');
  const personal = experiences.filter((x) => x.type === 'personal');
  const r = (x) => <Item key={x.title + x.org} title={x.title} sub={x.org} meta={x.period} text={x.description} tags={x.type ? [x.type] : []} />;
  return (
    <>
      <ListPage title="Experience" sub="Pengalaman profesional: formal, freelance, magang, volunteer, open-source." items={pro} render={r} />
      {personal.length > 0 && <ListPage title="Project pribadi" sub="Dipisahkan dari pengalaman profesional." items={personal} render={r} />}
    </>
  );
}
export const Organizations = () => <ListPage title="Organizations" items={organizations}
  render={(o) => <Item key={o.name} title={o.name} sub={o.role} meta={o.period} text={o.description} />} />;
export const Services = () => <ListPage title="Services" sub="Layanan yang tersedia." items={services}
  render={(s) => <Item key={s.title} title={s.title} text={s.description} meta={[s.estimate, s.price].filter(Boolean).join(' · ')} list={s.deliverables} tags={s.tech} />}>
  <div style={{ marginTop: '1.5rem' }}><Button to="/collaboration">Diskusikan kebutuhan Anda</Button></div></ListPage>;
export const Certificates = () => <ListPage title="Certificates" items={certificates}
  render={(c) => <Item key={c.title} title={c.title} sub={c.issuer} meta={c.year} text={c.url && <a href={c.url} target="_blank" rel="noopener noreferrer">Lihat kredensial</a>} />} />;
export const Achievements = () => <ListPage title="Achievements" items={achievements}
  render={(a) => <Item key={a.title} title={a.title} meta={a.year} text={a.description} />} />;
