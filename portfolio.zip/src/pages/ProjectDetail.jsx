import { useParams, Link } from 'react-router-dom';
import { projects } from '../data/data.js';
import { Badge, Button, SEO, Section } from '../components/common/ui.jsx';
import { NotFound } from './Misc.jsx';

export default function ProjectDetail() {
  const { slug } = useParams();
  const p = projects.find((x) => x.slug === slug);
  if (!p) return <NotFound />;
  return (
    <>
      <SEO title={p.title} description={p.description} />
      <Section>
        <Link to="/projects">← Semua project</Link>
        <h1 style={{ marginTop: '1rem' }}>{p.title}</h1>
        <p className="muted">{p.category} · {p.year} · {p.status}</p>
        {p.thumbnail && <img src={p.thumbnail} alt={`Tampilan ${p.title}`} style={{ maxWidth: '100%', borderRadius: 12 }} />}
        <p>{p.details}</p>
        <div className="row wrap">{p.tech.map((t) => <Badge key={t}>{t}</Badge>)}</div>
        {p.gallery.length > 0 && <div className="grid" style={{ marginTop: '1rem' }}>{p.gallery.map((g, i) => <img key={g} src={g} alt={`${p.title} ${i + 1}`} loading="lazy" style={{ width: '100%', borderRadius: 12 }} />)}</div>}
        <div className="row wrap" style={{ marginTop: '1.2rem' }}>
          {p.demo && <Button href={p.demo}>Live demo</Button>}
          {p.repo && <Button href={p.repo} variant="ghost">Repository</Button>}
        </div>
      </Section>
    </>
  );
}
